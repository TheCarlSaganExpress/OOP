/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.calcview2;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

/**
 *
 * @author easwaran
 */
public class myCalculator {
        // Adds input1 and input2
    public double doAddition(double x, double y)
    {
        return (x+y);
    }

    // Subtracts input2 from input1.
    public double doSubtraction(double x, double y)
    {
       return x-y;
    }

    // Multiplies the existing answer by a number.
    public double doMultiplication(double x, double y)
    {
        return x*y;
    }

    // Divides the existing answer by a number.
    public double doDivision(double x, double y)
    {   
      if (y==0.0){
         throw new ArithmeticException();
      }   
      return x/y;
    }
    public Object evaluateExpression(String expression) throws Exception{
	ScriptEngineManager mgr = new ScriptEngineManager();
	ScriptEngine engine = mgr.getEngineByName("JavaScript");
	return engine.eval(expression);
    }


}
